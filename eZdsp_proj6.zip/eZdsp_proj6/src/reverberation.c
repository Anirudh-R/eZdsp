/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*  reverberation.c                                                          */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5505 USB Stick. Reverberation based on 200 ms delay.             */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   27th January 2010. Created by Richard Sikora from C5510 code.           */
/*                                                                           */
/*****************************************************************************/

#include "ezdsp5502.h"

#define N 9600

#define DEPTH 30000

Int16 reverberation_array[N]; /* Buffer for maximum of 200 ms delay */

/*****************************************************************************/
/* reverberation_array_clear()                                               */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Fill reverberation_array[] used for reverberation with zeroes to prevent  */
/* noise and clicks.                                                         */
/*                                                                           */
/*****************************************************************************/

void reverberation_array_clear(void)
{
 int i;
 
 for ( i = 0 ; i < N ; i++)
  {
   reverberation_array[i] = 0;
  }
}

/*****************************************************************************/
/* reverberation()                                                           */
/*****************************************************************************/

Int16 reverberation( Int16 latest_input)
{
 static Int16 index = 0; /* Retain value between calls */
 long temp;
 long oldest_input;
 
 oldest_input =  ((long) reverberation_array[index] * DEPTH); /* Scale oldest sample */
 
 oldest_input >>= 15; /* Remove fractional part */
 
 temp = (long) latest_input + oldest_input; /* Newest + oldest */

 temp >>= 1;  /* Divide by two */
 
 if ( temp > 32767) /* Limit positive to maximum in case of overload */
   {
    temp = 32767;
   } 
 else if ( temp < -32767) /* Limit negative to minimum */
   { 
    temp = -32767;
   }
 
 reverberation_array[index] = temp; /* Overwrite buffer with new value */
 
 if ( index < N - 1)  /* Increment index if not at end of buffer */
   {
    index++;
   }  
 else
   {
    index = 0;  /* Otherwise go back to beginning of buffer */
   }
   
 return( (Int16) temp); /* Return new output */

}

/*****************************************************************************/
/* End of reverberation.c                                                    */
/*****************************************************************************/
