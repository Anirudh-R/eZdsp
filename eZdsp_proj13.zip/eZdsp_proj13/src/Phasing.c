/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*   Phasing.c                                                               */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   Phasing implmented using fractional delays.                             */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*                                                                           */
/*   Revision 1.00                                                           */
/*   16th June 2010. Created by Richard Sikora.                              */
/*                                                                           */
/*****************************************************************************/
/*
 *
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "tms320.h"
#include "dsplib.h"

#define LENGTH 32*6

DATA Hamming_Low_Pass_Filter_4000Hz[51] = {
             9,    -11,    -36,    -63,    -81,    -76,    -35,     44,
      150,    252,    307,    272,    120,   -143,   -468,   -764,   -914,
     -804,   -358,    441,   1528,   2760,   3947,   4884,   5400,   5400,
     4884,   3947,   2760,   1528,    441,   -358,   -804,   -914,   -764,
     -468,   -143,    120,    272,    307,    252,    150,     44,    -35,
      -76,    -81,    -63,    -36,    -11,      9,     23
};

DATA buffer[LENGTH];

static int counter = 0;
static int length = 0;
static DATA last_input = 0;
static DATA last_delayed_input = 0;
static int downsample_counter = 0;
static int offset = 0;

DATA fir1_input[2] = {0,0};
#pragma DATA_ALIGN(filtered_input, 2); 
DATA filtered_input[2];
#pragma DATA_ALIGN(output, 2); 
DATA output[2] = {0,0};
  
DATA dbuffer1[53];
DATA dbuffer2[53];

/*****************************************************************************/
/* phasing()                                                                 */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Comb notch filter of variable length up to 32 elements.                   */
/*                                                                           */
/*                                                                           */
/* PARAMETER 1: Audio input.                                                 */ 
/* PARAMETER 2: Update interval (in samples).                                */
/*                                                                           */
/*****************************************************************************/


DATA phasing(DATA input, int update_interval)
{
  
 fir1_input[0] = input;

 counter++;
 
 /* Update length of comb filter once every N update_rate samples */
 
 if ( counter == update_interval)
   {
    length++;          /* Count up only */
    counter = 0;
    
    if ( length >= LENGTH)
     {
      length = 18; /* Start with one sample delay at fs = 8000 Hz */
     } 
  
   }
 
 /* Remove all inputs above the Nyquist frequency */
 
  //filtered_input = FIR_filter_asm(&Hamming_Low_Pass_Filter_4000Hz[0], input);
  fir(&fir1_input[0], &Hamming_Low_Pass_Filter_4000Hz[0], &filtered_input[0], &dbuffer1[0], 1, 51);

  /* Increment pointer to circular buffer. Straight buffer would be too slow */
  offset++;
  
  if ( offset >= LENGTH )
   {
    offset = 0;
   }

  buffer[offset] = filtered_input[0];
  
  downsample_counter++;
  
  if ( downsample_counter >= 6)
   {
    downsample_counter = 0;
    last_input = buffer[offset];
    
    if ( offset + length >= LENGTH)
     {
      last_delayed_input = buffer[offset - LENGTH + length];
     }
    else
     { 
      last_delayed_input = buffer[offset+length];
     } 
   }

 /* y(n) =  x(n)/2 + x(n-N)/2 */

 output[0] = (last_input + last_delayed_input) >> 1;

 /* Upsample. Fill 1 in 6 outputs with signal. Fill other 5 with zeroes */

 if ( downsample_counter != 0)
 {output[0] = 0;}

   //output = anti_imaging_filter_asm(&Hamming_Low_Pass_Filter_4000Hz[0], output);
   fir(&output[0], &Hamming_Low_Pass_Filter_4000Hz[0], &output[0], &dbuffer2[0], 1, 51);


 return (output[0]);
}


/******************************************************************************/
/* End of Phasing.c                                                           */
/******************************************************************************/

