/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*   daubechies.c                                                            */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   Discrete Wavelet Transform (DWT) and Inverse Discrete Wavelet           */
/*   Transform (IDWT) using Debauchies4 Wavelets.                            */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*                                                                           */
/*   Revision 1.00                                                           */
/*   25th July 2010. Original code by Ian Kaplan at www.bearcave.com         */
/*                   Converted from floating-point to fixed-point.           */
/*                                                                           */
/*****************************************************************************/
/*
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


long h[4] = {15825, 27410, 7345,-4240 };
long g[4] = {-4240, -7345, 27410, -15825 };  

long Ih[4] ={ 7345, 27410, 15825, -4240 };
long Ig[4] ={-4240, -15825, 27410, -7345};


/* Temporary values for processing */
int tmp[32];


/*****************************************************************************/
/* transform()                                                               */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Input1: Signal inputs to transform.                                       */
/* Input2: Output wavelet coefficients                                       */
/* Input3: Number of values in buffer e.g. 4, 8, 16 or 32                    */ 
/*                                                                           */
/* Returns: Nothing.                                                         */
/*                                                                           */
/*****************************************************************************/


static void transform( int a[], int b[], int n)
{
  int i, j, half;
  long temp;
  
  if ( n >= 4) 
  {
    half = n>>1; 
  
   i = 0;
   for ( j = 0; j < n-3 ; j+=2 )
   {
    temp      = a[j]*h[0] + a[j+1]*h[1] + a[j+2]*h[2] + a[j+3]*h[3];
    tmp[i] = (int)( temp >>= 15);

	temp      = a[j]*g[0] + a[j+1]*g[1] + a[j+2]*g[2] + a[j+3]*g[3]; 
	tmp[i+half] = (int)( temp>>= 15);
	
	i++;
   }

   /* Process using wrap around values */
   temp       = a[n-2]*h[0] + a[n-1]*h[1] + a[0]*h[2] + a[1]*h[3];
   tmp[i] = (int)( temp >>= 15);


   temp       = a[n-2]*g[0] + a[n-1]*g[1] + a[0]*g[2] + a[1]*g[3];
   tmp[i+half] = (int)(temp >>= 15);

   /* Copy coefficients to output buffer */ 
   for ( i = 0 ; i < n ; i++ )
   {
     b[i] = tmp[i];
   }

  }

}

/*****************************************************************************/
/* inversetransform()                                                        */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Input1: Wavelet filter coefficients.                                      */ 
/* Input2: Reconstructed outputs.                                            */
/* Input3: Number of values in buffer e.g. 4, 8, 16 or 32.                   */
/*                                                                           */
/* Returns: Nothing.                                                         */
/*                                                                           */
/*****************************************************************************/

static void inversetransform(int a[], int b[], int n)
{
  int i, j, half, halfpls1;
  long temp;
  
  if ( n >= 4) 
  {
    half = n>>1;
	halfpls1 = half+1;

   /* Process using wrap around values */
   temp  = a[half-1]*Ih[0] + a[n-1]*Ih[1] + a[0]*Ih[2] + a[half]*Ih[3];
   tmp[0] = (int)(temp >>= 15);

   temp  = a[half-1]*Ig[0] + a[n-1]*Ig[1] + a[0]*Ig[2] + a[half]*Ig[3]; 	
   tmp[1] = (int)(temp >>= 15);

   j = 2;
   for ( i = 0; i < half-1 ; i++ )
   {
     temp = a[i]*Ih[0] + a[i+half]*Ih[1] + a[i+1]*Ih[2] + a[i+halfpls1]*Ih[3];
	 tmp[j++] = (int)(temp >>= 15);

	 temp = a[i]*Ig[0] + a[i+half]*Ig[1] + a[i+1]*Ig[2] + a[i+halfpls1]*Ig[3];
	 tmp[j++] = (int)(temp >>= 15);
   }

   for ( i = 0 ; i < n ; i++)
   {
     b[i] = tmp [i];
   } 

  } 

 }

/*****************************************************************************/
/* Daubechies()                                                              */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Parameter1: Latest audio input.                                           */
/* Parameter2: Pointer to array holding the wavelet coefficients.            */
/*                                                                           */
/* Returns: Nothing.                                                         */
/*                                                                           */
/*****************************************************************************/


void Daubechies(int inputs[], int coefficients[], int N )
{
 int n;

 for ( n = N ; n >= 4; n >>= 1)
 {
   transform( &inputs[0], &coefficients[0], n);
 } 

}

/*****************************************************************************/
/* invDaubechies()                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Parameter1: Pointer to reconstructred data.                               */ 
/*                                                                           */
/* Returns: Nothing.                                                         */
/*                                                                           */
/*****************************************************************************/

void invDaubechies( int coefficients[], int outputs[], int N)
{
  int n;

 for ( n = 4; n <= N ; n <<= 1)
 {
   inversetransform( &coefficients[0], &outputs[0],  n); 
 }

}

/*****************************************************************************/
/* End of daubechies.c                                                       */
/*****************************************************************************/




