/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */ 
/*   daubechies.h                                                            */                           
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5505 USB Stick.                                                  */
/*   Header file for converting Daubechies wavelets.                         */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */ 
/*   Author  : Richard Sikora                                                */ 
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   26 July 2010. Created by Richard Sikora.                                */
/*                                                                           */
/*****************************************************************************/

#ifndef DAUBECHIES_H
#define DAUBECHIES_H

void Daubechies(int inputs[], int coefficients[], int N );

void invDaubechies( int coefficients[], int outputs[], int N);

#endif

/*****************************************************************************/
/* End of daubechies.h                                                       */
/*****************************************************************************/
