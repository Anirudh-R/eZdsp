/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*   combfilters.c                                                           */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   Notch and bandpass comb filters for the TMS320VC5505 USB Stick.         */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*                                                                           */
/*   Revision 1.00                                                           */
/*   16th June 2010. Created by Richard Sikora.                              */
/*                                                                           */
/*****************************************************************************/
/*
 *
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "ezdsp5502.h"

#define LENGTH 32
#define GAIN  31000L //26214L
#define SCALE 1000   //29490

int buffer[LENGTH];
int buffer2[LENGTH];


/*****************************************************************************/
/* comb_notch_filter()                                                       */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Comb notch filter of variable length up to 32 elements.                   */
/*                                                                           */
/*                                                                           */
/* PARAMETER 1: Audio input.                                                 */ 
/* PARAMETER 2: Length of comb filters between 2 and 32.                     */
/*                                                                           */
/*****************************************************************************/


Int16 comb_notch_filter(Int16 input, Uint16 length)
{
 Int16 i;
 long output;

 /* Check that parameter length is not off the end of the buffer */ 
 if ( length > LENGTH)
  {
    length = LENGTH;
  }
 
 /* Shuffle values along one place */

 for ( i = length-2; i >= 0 ; i--)
  {
    buffer[i+1] = buffer[i];
  }

 /* Save new input */

 buffer[0] = input; 

 /* y(n) =  x(n)/2 + x(n-N)/2 */

 output = (buffer[0] + buffer[length-1]) >> 1; 

 return ((Int16)output);
}


/*****************************************************************************/
/* comb_band_pass_filter()                                                   */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Comb notch filter of variable length up to 32 elements. G = 0.8           */
/*                                                                           */
/*                                                                           */
/* PARAMETER 1: Audio input.                                                 */ 
/* PARAMETER 2: Length of comb filters between 2 and 32.                     */
/*                                                                           */
/*****************************************************************************/


Int16 comb_band_pass_filter(Int16 input, Uint16 length)
{
 Int16 i;
 long output;

 /* Check that parameter length is not off the end of the buffer */ 
 if ( length > LENGTH)
  {
    length = LENGTH;
  }
 
 /* Shuffle values along one place */

 for ( i = length-2; i >= 0 ; i--)
  {
    buffer2[i+1] = buffer2[i];
  }


 /* y(n) =  (x(n)+ G. y(n-N) ) * (1+G) */

 output = (GAIN * buffer2[length-1]) >> 15;  

 output += input;

 output = (output * SCALE) >> 15;


 /* Save latest output y(n) */

 buffer2[0] = output; 
 

 return ((Int16)output);
}

/******************************************************************************/
/* End of combfilters.c                                                       */
/******************************************************************************/

