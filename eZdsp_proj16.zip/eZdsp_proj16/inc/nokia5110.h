//////////////////////////////////////////////////////////////////////////////
// * File name: nokia5110.h
// *                                                                          
// * Description:  Provides functions to use with Nokia 5110 module                                                                            
// *                                                                          
//////////////////////////////////////////////////////////////////////////////

#include "ezdsp5502.h"
#include "csl_mcbsp.h"
#include "ezdsp5502_gpio.h"
#include "string.h"

/* SPI and Display settings */
#define RESET 	 		GPIO_PIN2	//Use GPIO2 as RESET
#define D_C	     		GPIO_PIN6	//Use GPIO6 as D/~C
#define DEFCONTR 		0x4F	  	//Default contrast value, VOP = 0x3F => 6.84V
#define DEFSPACING		2			//Default spacing between chars
#define CLKDIV_VALUE 	24			//CLKGDV = 24; 75MHz/(24+1) = 3MHz SPI clock

void nokia5110_print(const char* str);
void nokia5110_gotoLine(Uint8 val);
void nokia5110_setSpacing(Uint8 val);
void nokia5110_setContrast(Uint8 val);
void nokia5110_invert();
void nokia5110_reset( );
void nokia5110_init( );
