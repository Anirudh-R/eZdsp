//////////////////////////////////////////////////////////////////////////////
// * File name: nokia5110.c
// *                                                                          
// * Description:  Implements interface and display functions for the Nokia 5110 module
// *               which has the PCD8544 display driver chip.
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
 
#include "nokia5110.h"

#define CLKG_FREQ	    (75.0/(float)(CLKDIV_VALUE+1))
#define CLKG_CYCLES		(Uint16)(300.0/CLKG_FREQ)
#define DELAY_2CLKG		((2*CLKG_CYCLES)/4)

/* Display modes */
#define MODE_BLANK   0x08
#define MODE_ALLON   0x09
#define MODE_NORMAL  0x0C
#define MODE_INV     0x0D

MCBSP_Handle nokiaSPI;

static Uint8 spacing = DEFSPACING;
static Uint8 Xaddr = 0;

void nokia5110_write( Uint8 data );
void nokia5110_close( );
void nokia5110_gotoXY(Uint8 x, Uint8 y);
void nokia5110_setMode(Uint8 mode);

// This table contains the hex values that represent pixels
// for a font that is 5 pixels wide and 8 pixels high
// Means upto 14 chars per line with single pixel spacing
static const Uint8 ASCII[][5] =
{
	  {0x00, 0x00, 0x00, 0x00, 0x00} // 20 space
	, {0x00, 0x00, 0x5f, 0x00, 0x00} // 21 !
	, {0x00, 0x07, 0x00, 0x07, 0x00} // 22 "
	, {0x14, 0x7f, 0x14, 0x7f, 0x14} // 23 #
	, {0x24, 0x2a, 0x7f, 0x2a, 0x12} // 24 $
	, {0x23, 0x13, 0x08, 0x64, 0x62} // 25 %
	, {0x36, 0x49, 0x55, 0x22, 0x50} // 26 &
	, {0x00, 0x05, 0x03, 0x00, 0x00} // 27 '
	, {0x00, 0x1c, 0x22, 0x41, 0x00} // 28 (
	, {0x00, 0x41, 0x22, 0x1c, 0x00} // 29 )
	, {0x14, 0x08, 0x3e, 0x08, 0x14} // 2a *
	, {0x08, 0x08, 0x3e, 0x08, 0x08} // 2b +
	, {0x00, 0x50, 0x30, 0x00, 0x00} // 2c ,
	, {0x08, 0x08, 0x08, 0x08, 0x08} // 2d -
	, {0x00, 0x60, 0x60, 0x00, 0x00} // 2e .
	, {0x20, 0x10, 0x08, 0x04, 0x02} // 2f /
	, {0x3e, 0x51, 0x49, 0x45, 0x3e} // 30 0
	, {0x00, 0x42, 0x7f, 0x40, 0x00} // 31 1
	, {0x42, 0x61, 0x51, 0x49, 0x46} // 32 2
	, {0x21, 0x41, 0x45, 0x4b, 0x31} // 33 3
	, {0x18, 0x14, 0x12, 0x7f, 0x10} // 34 4
	, {0x27, 0x45, 0x45, 0x45, 0x39} // 35 5
	, {0x3c, 0x4a, 0x49, 0x49, 0x30} // 36 6
	, {0x01, 0x71, 0x09, 0x05, 0x03} // 37 7
	, {0x36, 0x49, 0x49, 0x49, 0x36} // 38 8
	, {0x06, 0x49, 0x49, 0x29, 0x1e} // 39 9
	, {0x00, 0x36, 0x36, 0x00, 0x00} // 3a :
	, {0x00, 0x56, 0x36, 0x00, 0x00} // 3b ;
	, {0x08, 0x14, 0x22, 0x41, 0x00} // 3c <
	, {0x14, 0x14, 0x14, 0x14, 0x14} // 3d =
	, {0x00, 0x41, 0x22, 0x14, 0x08} // 3e >
	, {0x02, 0x01, 0x51, 0x09, 0x06} // 3f ?
	, {0x32, 0x49, 0x79, 0x41, 0x3e} // 40 @
	, {0x7e, 0x11, 0x11, 0x11, 0x7e} // 41 A
	, {0x7f, 0x49, 0x49, 0x49, 0x36} // 42 B
	, {0x3e, 0x41, 0x41, 0x41, 0x22} // 43 C
	, {0x7f, 0x41, 0x41, 0x22, 0x1c} // 44 D
	, {0x7f, 0x49, 0x49, 0x49, 0x41} // 45 E
	, {0x7f, 0x09, 0x09, 0x09, 0x01} // 46 F
	, {0x3e, 0x41, 0x49, 0x49, 0x7a} // 47 G
	, {0x7f, 0x08, 0x08, 0x08, 0x7f} // 48 H
	, {0x00, 0x41, 0x7f, 0x41, 0x00} // 49 I
	, {0x20, 0x40, 0x41, 0x3f, 0x01} // 4a J
	, {0x7f, 0x08, 0x14, 0x22, 0x41} // 4b K
	, {0x7f, 0x40, 0x40, 0x40, 0x40} // 4c L
	, {0x7f, 0x02, 0x0c, 0x02, 0x7f} // 4d M
	, {0x7f, 0x04, 0x08, 0x10, 0x7f} // 4e N
	, {0x3e, 0x41, 0x41, 0x41, 0x3e} // 4f O
	, {0x7f, 0x09, 0x09, 0x09, 0x06} // 50 P
	, {0x3e, 0x41, 0x51, 0x21, 0x5e} // 51 Q
	, {0x7f, 0x09, 0x19, 0x29, 0x46} // 52 R
	, {0x46, 0x49, 0x49, 0x49, 0x31} // 53 S
	, {0x01, 0x01, 0x7f, 0x01, 0x01} // 54 T
	, {0x3f, 0x40, 0x40, 0x40, 0x3f} // 55 U
	, {0x1f, 0x20, 0x40, 0x20, 0x1f} // 56 V
	, {0x3f, 0x40, 0x38, 0x40, 0x3f} // 57 W
	, {0x63, 0x14, 0x08, 0x14, 0x63} // 58 X
	, {0x07, 0x08, 0x70, 0x08, 0x07} // 59 Y
	, {0x61, 0x51, 0x49, 0x45, 0x43} // 5a Z
	, {0x00, 0x7f, 0x41, 0x41, 0x00} // 5b [
	, {0x02, 0x04, 0x08, 0x10, 0x20} // 5c backslash
	, {0x00, 0x41, 0x41, 0x7f, 0x00} // 5d ]
	, {0x04, 0x02, 0x01, 0x02, 0x04} // 5e ^
	, {0x40, 0x40, 0x40, 0x40, 0x40} // 5f _
	, {0x00, 0x01, 0x02, 0x04, 0x00} // 60 `
	, {0x20, 0x54, 0x54, 0x54, 0x78} // 61 a
	, {0x7f, 0x48, 0x44, 0x44, 0x38} // 62 b
	, {0x38, 0x44, 0x44, 0x44, 0x20} // 63 c
	, {0x38, 0x44, 0x44, 0x48, 0x7f} // 64 d
	, {0x38, 0x54, 0x54, 0x54, 0x18} // 65 e
	, {0x08, 0x7e, 0x09, 0x01, 0x02} // 66 f
	, {0x0c, 0x52, 0x52, 0x52, 0x3e} // 67 g
	, {0x7f, 0x08, 0x04, 0x04, 0x78} // 68 h
	, {0x00, 0x44, 0x7d, 0x40, 0x00} // 69 i
	, {0x20, 0x40, 0x44, 0x3d, 0x00} // 6a j
	, {0x7f, 0x10, 0x28, 0x44, 0x00} // 6b k
	, {0x00, 0x41, 0x7f, 0x40, 0x00} // 6c l
	, {0x7c, 0x04, 0x18, 0x04, 0x78} // 6d m
	, {0x7c, 0x08, 0x04, 0x04, 0x78} // 6e n
	, {0x38, 0x44, 0x44, 0x44, 0x38} // 6f o
	, {0x7c, 0x14, 0x14, 0x14, 0x08} // 70 p
	, {0x08, 0x14, 0x14, 0x18, 0x7c} // 71 q
	, {0x7c, 0x08, 0x04, 0x04, 0x08} // 72 r
	, {0x48, 0x54, 0x54, 0x54, 0x20} // 73 s
	, {0x04, 0x3f, 0x44, 0x40, 0x20} // 74 t
	, {0x3c, 0x40, 0x40, 0x20, 0x7c} // 75 u
	, {0x1c, 0x20, 0x40, 0x20, 0x1c} // 76 v
	, {0x3c, 0x40, 0x30, 0x40, 0x3c} // 77 w
	, {0x44, 0x28, 0x10, 0x28, 0x44} // 78 x
	, {0x0c, 0x50, 0x50, 0x50, 0x3c} // 79 y
	, {0x44, 0x64, 0x54, 0x4c, 0x44} // 7a z
	, {0x00, 0x08, 0x36, 0x41, 0x00} // 7b {
	, {0x00, 0x00, 0x7f, 0x00, 0x00} // 7c |
	, {0x00, 0x41, 0x36, 0x08, 0x00} // 7d }
	, {0x10, 0x08, 0x08, 0x10, 0x08} // 7e ~
	, {0x78, 0x46, 0x41, 0x46, 0x78} // 7f DEL
};



/*
 *  nokia5110_init( )
 *
 *  Description:
 *      Configure as SPI and initalize the MCBSP0 for use
 *      with the nokia5110. We need only transmitter part.
 */
void nokia5110_init( )
{
    /* Set values for MCBSP configuration structure */
    MCBSP_Config configSPI = {
          MCBSP_SPCR1_RMK(
          MCBSP_SPCR1_DLB_OFF,          // DLB    = 0
          MCBSP_SPCR1_RJUST_RZF,        // RJUST  = 0 (Right Justified)
          MCBSP_SPCR1_CLKSTP_DELAY,   	// CLKSTP = 11 (SPI mode)
          MCBSP_SPCR1_DXENA_NA,         // DXENA  = 0
          MCBSP_SPCR1_ABIS_DISABLE,     // ABIS   = 0
          MCBSP_SPCR1_RINTM_RRDY,       // RINTM  = 0
          MCBSP_SPCR1_RSYNCERR_NO ,     // RSYNCERR = 0
          MCBSP_SPCR1_RRST_DISABLE      // RRST   = 0
          ),
        MCBSP_SPCR2_RMK(
          MCBSP_SPCR2_FREE_NO,          // FREE   = 0 (Not Free running)
          MCBSP_SPCR2_SOFT_YES,         // SOFT   = 1 (Soft stop)
          MCBSP_SPCR2_FRST_RESET,       // FRST   = 0 (Frame sync in reset)
          MCBSP_SPCR2_GRST_RESET,       // GRST   = 0 (SRG in reset)
          MCBSP_SPCR2_XINTM_XRDY,       // XINTM  = 0
          MCBSP_SPCR2_XSYNCERR_NO,      // XSYNCERR = N/A
          MCBSP_SPCR2_XRST_DISABLE      // XRST   = 0
          ),
        MCBSP_RCR1_RMK( 
          MCBSP_RCR1_RFRLEN1_OF(0),     // RFRLEN1 = 0 (1 Word per frame)
          MCBSP_RCR1_RWDLEN1_8BIT       // RWDLEN1 = 0 (8-bit)
          ),
        MCBSP_RCR2_RMK(    
          MCBSP_RCR2_RPHASE_SINGLE,     // RPHASE  = 0 (Single Phase)
          MCBSP_RCR2_RFRLEN2_OF(0),     // RFRLEN2 = 0
          MCBSP_RCR2_RWDLEN2_8BIT,      // RWDLEN2 = 0
          MCBSP_RCR2_RCOMPAND_MSB,      // RCOMPAND = 0
          MCBSP_RCR2_RFIG_NO,           // RFIG    = 1 (Ignore)
          MCBSP_RCR2_RDATDLY_1BIT       // RDATDLY = 01 (1-bit delay)
          ),  
        MCBSP_XCR1_RMK(    
          MCBSP_XCR1_XFRLEN1_OF(0),     // XFRLEN1 = 0 (1 Word per frame)
          MCBSP_XCR1_XWDLEN1_8BIT       // XWDLEN1 = 0 (8-bit)
          ),   
        MCBSP_XCR2_RMK(   
          MCBSP_XCR2_XPHASE_SINGLE,     // XPHASE  = 0 (Single Phase)
          MCBSP_XCR2_XFRLEN2_OF(0),     // XFRLEN2 = 0
          MCBSP_XCR2_XWDLEN2_8BIT,      // XWDLEN2 = 0
          MCBSP_XCR2_XCOMPAND_MSB,      // XCOMPAND = 0
          MCBSP_XCR2_XFIG_NO,           // XFIG    = 1 (Ignore)
          MCBSP_XCR2_XDATDLY_1BIT       // XDATDLY = 01 (1-bit delay)
          ),            
        MCBSP_SRGR1_RMK( 
          MCBSP_SRGR1_FWID_OF(0),      		  // FWID    = 0 (N/A for SPI)
          MCBSP_SRGR1_CLKGDV_OF(CLKDIV_VALUE) // CLKGDV = CLKDIV_VALUE
          ),   
        MCBSP_SRGR2_RMK(  
          MCBSP_SRGR2_GSYNC_FREE,      // N/A for C5502
          MCBSP_SRGR2_CLKSP_RISING,    // CLKSP   = 0
          MCBSP_SRGR2_CLKSM_INTERNAL,  // CLKSM   = 1
          MCBSP_SRGR2_FSGM_DXR2XSR,    // FSGM    = 0 
          MCBSP_SRGR2_FPER_OF(0)       // FPER    = 0 (N/A for SPI)
          ),  
        MCBSP_MCR1_DEFAULT,
        MCBSP_MCR2_DEFAULT, 
        MCBSP_PCR_RMK(
          MCBSP_PCR_XIOEN_SP,          // XIOEN    = 0   
          MCBSP_PCR_RIOEN_SP,          // RIOEN    = 0   
          MCBSP_PCR_FSXM_INTERNAL,     // FSXM     = 1   
          MCBSP_PCR_FSRM_EXTERNAL,     // FSRM     = 0  
          MCBSP_PCR_CLKXM_OUTPUT,      // CLKXM    = 1  
          MCBSP_PCR_CLKRM_INPUT,       // CLKRM    = 0   
          MCBSP_PCR_SCLKME_NO,         // SCLKME   = 0   
          0,                           // DXSTAT = N/A   
          MCBSP_PCR_FSXP_ACTIVELOW,    // FSXP     = 1   
          MCBSP_PCR_FSRP_ACTIVELOW,    // FSRP     = 1   
          MCBSP_PCR_CLKXP_RISING,      // CLKXP    = 0   
          MCBSP_PCR_CLKRP_RISING       // CLKRP    = 1   
          ),
        MCBSP_RCERA_DEFAULT, 
        MCBSP_RCERB_DEFAULT, 
        MCBSP_RCERC_DEFAULT, 
        MCBSP_RCERD_DEFAULT, 
        MCBSP_RCERE_DEFAULT, 
        MCBSP_RCERF_DEFAULT, 
        MCBSP_RCERG_DEFAULT, 
        MCBSP_RCERH_DEFAULT, 
        MCBSP_XCERA_DEFAULT,
        MCBSP_XCERB_DEFAULT,
        MCBSP_XCERC_DEFAULT,
        MCBSP_XCERD_DEFAULT,  
        MCBSP_XCERE_DEFAULT,
        MCBSP_XCERF_DEFAULT,  
        MCBSP_XCERG_DEFAULT,
        MCBSP_XCERH_DEFAULT
        };

    /* Close any previous instance of the SPI interface */
    nokia5110_close( );

    /* Open the SPI interface and reset it */
    nokiaSPI = MCBSP_open(MCBSP_PORT0, MCBSP_OPEN_RESET);

    /* Configure McBSP with values */
    MCBSP_config(nokiaSPI, &configSPI);
    
    /* Enable Sample Rate Generator and wait 2 CLKG cycles for it to stabilize */
    MCBSP_start(nokiaSPI, MCBSP_SRGR_START, DELAY_2CLKG);
    
    /* Enable MCBSP transmitter and wait 2 CLKG cycles */
    MCBSP_start(nokiaSPI, MCBSP_XMIT_START, DELAY_2CLKG);
    
    /* Module initialization */
    EZDSP5502_GPIO_setOutput(RESET, 1);	 //remove from reset
    
    EZDSP5502_GPIO_setOutput(D_C, 0);	 //command
	nokia5110_write(0x21);	//remove from power-down, horiz addr, ext instn set
	
    /* Enable FRAMESYNC logic, first data will be tx after 8 CLKGs */
    MCBSP_start(nokiaSPI, MCBSP_SRGR_FRAMESYNC, 0);
	
    //Set contrast
    nokia5110_setContrast(DEFCONTR);
	
	nokia5110_write(0x04);	//Temp coefficient
	nokia5110_write(0x13);  //Bias mode
    
    //basic instn set
    nokia5110_write(0x20);
    
    //Set Display mode to normal
	nokia5110_setMode(MODE_NORMAL);
    
    //Clear the display
	nokia5110_clear();
}


/*
 *  nokia5110_print( str )
 *
 *  const char* str   <- string to display
 * 
 *  Description:
 *      Displays string at current line. Truncates if too long.
 */
void nokia5110_print(const char* str)
{
	Uint8 len, count, k, i;
	
	len = strlen(str);

    EZDSP5502_GPIO_setOutput(D_C, 1);	//Data
	
	count = 0;
	while((count < len) && (Xaddr + 5 <= 84)) //space left in current line?
	{
		//print character
		k = str[count++] - 0x20;
		for(i = 0; i < 5; i++)
			nokia5110_write(ASCII[k][i]);
    	
    	Xaddr += 5;

    	//insert required spacing after character
    	if(Xaddr + spacing <= 84)
    	{
    		k = spacing;
    		while(k--)
    			nokia5110_write(0x00);
    		
     		Xaddr += spacing;
    	}
	}
}


/*
 *  nokia5110_dispSpectrum( arr, n )
 *
 *  Int16* arr   <- array with normalized fft abs
 *  Uint16 n	 <- size of arr
 * 
 *  Description:
 * 		Plots the spectrum like an histogram. Data
 * 		in arr is lost.
 */
void nokia5110_dispSpectrum(Int16* arr, Uint16 n)
{
	int r, i, j;

	for(i = 0; i < 6; i++)	//rows
	{
		nokia5110_gotoLine(i);
		EZDSP5502_waitusec(3);
    	EZDSP5502_GPIO_setOutput(D_C, 1);	//Data
		for(j = 0; j < n; j++)	 //columns
		{
			if( (r = arr[j] - 8*(5-i)) > 0 )  //Needs to be printed
			{
				nokia5110_write(0xFF << (8-r));
				arr[j] -= r;
			}
			else							 //Print blank
			{
				nokia5110_write(0x00);
			}
		}
	}
}


/*
 *  nokia5110_dispFreq( freq )
 *
 *  Uint16 freq   <- frequency to display
 * 
 *  Description:
 *      Displays upto 2 digit before and 1 digit 
 * 		after decimal point. Eg., 6.74KHz -> "067"
 */
void nokia5110_dispFreq(Uint16 freq)
{
	Uint8 dig1, dig2, dig3;
	char s[] = "0";
	
	dig1 = freq/10000;
	freq %= 10000;
	dig2 = freq/1000;
	freq %= 1000;
	dig3 = freq/100;
	
	nokia5110_gotoXY(65, 1);
	
	s[0] = dig1 + '0';
	nokia5110_print(s);
	s[0] = dig2 + '0';
	nokia5110_print(s);
	s[0] = dig3 + '0';
	nokia5110_print(s);
}


/*
 *  nokia5110_gotoLine( val )
 *
 *  Uint8 val   <- line no., between 0 and 5
 * 
 *  Description:
 *      Sets cursor to start of given line number.
 */
void nokia5110_gotoLine(Uint8 val)
{
	if(val > 5)
		val = 5;
	
    EZDSP5502_GPIO_setOutput(D_C, 0);	//command
    
    nokia5110_write(0x20);     //basic instn set
    
	nokia5110_write(0x80);			//set X addr
	nokia5110_write(val | 0x40);	//set Y addr
	
	Xaddr = 0;
}


/*
 *  nokia5110_gotoXY( x, y )
 *
 *  Uint8 x   <- x coordinate
 *  Uint8 y   <- y coordinate
 * 
 *  Description:
 *      Sets cursor to given x and y coordinates.
 */
void nokia5110_gotoXY(Uint8 x, Uint8 y)
{
	if(x > 83)
		x = 83;
	
	if(y > 5)
		y = 5;
	
    EZDSP5502_GPIO_setOutput(D_C, 0);	//command
    
    nokia5110_write(0x20);     //basic instn set
    
	nokia5110_write(x | 0x80);	//set X addr
	nokia5110_write(y | 0x40);	//set Y addr
	
	Xaddr = x;
}


/*
 *  nokia5110_setMode(  )
 * 
 *  Description:
 *      Sets display mode. mode should be one
 * 		of the defined modes.
 */
void nokia5110_setMode(Uint8 mode)
{
	EZDSP5502_GPIO_setOutput(D_C, 0);	//command
    
    nokia5110_write(0x20);     //basic instn set
	
	nokia5110_write(mode);     
}


/*
 *  nokia5110_clear(  )
 * 
 *  Description:
 *      Clears the display.
 */
void nokia5110_clear()
{
    nokia5110_gotoLine(0);
    nokia5110_print("            ");
    nokia5110_gotoLine(1);
    nokia5110_print("            ");
    nokia5110_gotoLine(2);
    nokia5110_print("            ");
    nokia5110_gotoLine(3);
    nokia5110_print("            ");
    nokia5110_gotoLine(4);
    nokia5110_print("            ");
    nokia5110_gotoLine(5);
    nokia5110_print("            ");
    nokia5110_gotoLine(0);
}


/*
 *  nokia5110_setSpacing( val )
 *
 *  Uint8 val   <- spacing, between 1 and 4
 * 
 *  Description:
 *      Sets the spacing between characters.
 */
void nokia5110_setSpacing(Uint8 val)
{
	if(val > 4)
		spacing = 4;
	else if(val < 1)
		spacing = 1;
	else
		spacing = val;
}


/*
 *  nokia5110_setContrast( val )
 *
 *  Uint8 val   <-  VOP[6:0] bits value, MSB should be 1
 * 
 *  Description:
 *      Sets the contrast of LCD
 */
void nokia5110_setContrast(Uint8 val)
{
    EZDSP5502_GPIO_setOutput(D_C, 0);	

	nokia5110_write(0x21);	//ext instn set

    val |= 0x80;	//Ensure MSB is 1 
	nokia5110_write(val);	
}


/*
 *  nokia5110_invert(  )
 * 
 *  Description:
 *      Inverts the background and text colours.
 */
void nokia5110_invert()
{
	static Uint8 state = 0;
	
    EZDSP5502_GPIO_setOutput(D_C, 0);	 
    
    nokia5110_write(0x20);     //basic instn set
    
    if(state == 0)
    	nokia5110_write(0x0D);	//inverse video mode
    else
    	nokia5110_write(0x0C);	//normal mode
    	
    state = ~state;
}


/*
 *  nokia5110_reset( )
 *
 *  Description:
 *      Puts the module into reset
 */
void nokia5110_reset( )
{
	/* Uses GPIO2 as RESET, GPIO6 as D/~C */
    EZDSP5502_GPIO_init(RESET | D_C);		
    EZDSP5502_GPIO_setDirection(RESET | D_C, 
    							GPIO_PIN2_OUTPUT | GPIO_PIN6_OUTPUT);
    
    //Put D_C in a known state
    EZDSP5502_GPIO_setOutput(D_C, 0);
    
    //Assert RESET
	EZDSP5502_GPIO_setOutput(RESET, 0);
	EZDSP5502_waitusec(10); 	//Wait atleast 100ns
}


/*
 *  nokia5110_write( data )
 *
 *      Uint8 data   <-  8-bit data
 * 
 *  Description:
 *      Sends data to the module
 */
void nokia5110_write( Uint8 data )
{
    while(!MCBSP_xrdy(nokiaSPI));
    
    MCBSP_write16(nokiaSPI, (Uint16)data);
    
    while(!MCBSP_xrdy(nokiaSPI));
    EZDSP5502_waitusec(3);
}


/*
 *  nokia5110_close( )
 *
 *  Description:
 *      Closes the SPI interface
 */
void nokia5110_close( )
{
    MCBSP_close(nokiaSPI);
}

