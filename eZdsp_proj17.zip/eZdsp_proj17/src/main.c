//////////////////////////////////////////////////////////////////////////////
// * File name: main.c
// *                                                                          
// * Description:  Main function.
// *                                                                          
// * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/ 
// * Copyright (C) 2011 Spectrum Digital, Incorporated
// *                                                                          
// *                                                                          
// *  Redistribution and use in source and binary forms, with or without      
// *  modification, are permitted provided that the following conditions      
// *  are met:                                                                
// *                                                                          
// *    Redistributions of source code must retain the above copyright        
// *    notice, this list of conditions and the following disclaimer.         
// *                                                                          
// *    Redistributions in binary form must reproduce the above copyright     
// *    notice, this list of conditions and the following disclaimer in the   
// *    documentation and/or other materials provided with the                
// *    distribution.                                                         
// *                                                                          
// *    Neither the name of Texas Instruments Incorporated nor the names of   
// *    its contributors may be used to endorse or promote products derived   
// *    from this software without specific prior written permission.         
// *                                                                          
// *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
// *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
// *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
// *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
// *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
// *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
// *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
// *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
// *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
// *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
// *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
#include "ezdsp5502.h"
#include "ezdsp5502_gpio.h"
#include "ezdsp5502_mcbsp.h"
#include "ezdsp5502_i2cgpio.h"
#include "timer.h"
#include "nokia5110.h"
#include "sinewaves.h"
#include "i2cgpio.h"
#include "csl_chip.h"
#include "csl_mcbsp.h"
#include "stdio.h"

#include "tms320.h"
#include "dsplib.h"
#include "math.h"

#define FFTSIZE  128u	
#define Nh 		 51

void configPort(void);
void checkTimer(void);
void checkSwitch(void);

extern void initPLL(void);
extern void initAIC3204( );

extern Uint16 timerFlag;  // Timer interrupt flag

Uint8 sw1State = 0;       // SW1 state
Uint8 sw2State = 0;       // SW2 state

#pragma DATA_SECTION(fftbuffer, ".fftinput")
DATA fftbuffer[2*FFTSIZE];	//buffer to collect samples 

void main(void)
{   
	Int16 data_in_L = 0;
	Int16 data_in_R = 0;
	
	DATA tmpbuffer[FFTSIZE/2];	//buffer having normalized fft abs
	Uint16 sampCnt = 0;			//no. of samples collected	
	DATA fftabsmax, fftabsmaxindx, temp1, i;
	
    /* Initializations */
    initPLL( );         // Initialize PLL
    EZDSP5502_init( );  // Board Initialization
    
    nokia5110_reset( );	//Reset the display, DO THIS AT THE EARLIEST!
    initLed( );         // Init I2C GPIO for LEDs
    configPort( );      // Configure MUXs
    initTimer0( );      // Initialize timer
    initAIC3204( );     // Initialize AIC3204
    nokia5110_init( );  // Init display
    
    /* Start Demo */
    startTimer0( );           // Start timer
    EZDSP5502_MCBSP_init( );  // Configure and start McBSP
    
    printf("\nInitializations done!!\n");
    
    while(1)
    {
    	EZDSP5502_MCBSP_read(&data_in_L);
    	EZDSP5502_MCBSP_read(&data_in_R);
    	
    	data_in_L = generate_sinewave_1(2500, 1000);
    	data_in_R = generate_sinewave_2(8000, 2000);
    	
    	/* Collect FFTSIZE samples */
    	fftbuffer[sampCnt++] = (DATA)(((Int32)data_in_L + data_in_R)>>1);
   		fftbuffer[sampCnt]   = 0;
   		
   		if(sampCnt == 2*FFTSIZE-1)
   		{	
   			/* radix-2 FFT */
   			cfft(fftbuffer, FFTSIZE, SCALE);
    		cbrev(fftbuffer, fftbuffer, FFTSIZE);
			
			/* Find FFT and its magnitude */
			fftabsmax = 0;
			fftabsmaxindx = 0;
			for(i = 2; i < FFTSIZE; i += 2)
			{
				temp1 = sqrt((Int32)fftbuffer[i]*fftbuffer[i] + (Int32)fftbuffer[i+1]*fftbuffer[i+1]);
				
				if(temp1 > fftabsmax)
				{
					fftabsmax = temp1;
					fftabsmaxindx = i>>1;
				}
				
				tmpbuffer[i>>1] = temp1;
			}
   			
   			tmpbuffer[0] = 0;	//Remove absolute DC
   			
   			/* Normalize to the display hight */
   			if(fftabsmax != 0)
   			{
				for(i = 1; i < FFTSIZE/2; i++)
				{
					tmpbuffer[i] = (DATA)(((long)tmpbuffer[i]*48)/fftabsmax);
					
					if(tmpbuffer[i] < 0)
						tmpbuffer[i] = tmpbuffer[i-1];
				}
   			}
   			
   			/* Plot */
			nokia5110_dispSpectrum(tmpbuffer, FFTSIZE/2);
			nokia5110_dispFreq(fftabsmaxindx*375);			//24KHz/64 = 375Hz resolution
				
   			sampCnt = 0;
   		}
   		else
   		{
   			sampCnt++;
   		}
    }
}



/*
 *  configPort( )
 *
 *   Configure MUXs for AIC3204 and external SPI
 *   Enable FTDI UART
 */
void configPort(void)
{
    /* Route McBSP1 to AIC */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1, LOW );
    
    /* Enable McBSP1 mux */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1_ENn, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1_ENn, LOW );
    
    /* Route McBSP0 to Wireless connector I2S channel 
     * which also goes to SPI of expansion connector */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL0, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL0, LOW );
    
    /* Enable McBSP0 mux */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL0_ENn, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL0_ENn, LOW );
    
    /* Enable FTDI UART */
    EZDSP5502_I2CGPIO_configLine( FTDI_UARTn, OUT );
    EZDSP5502_I2CGPIO_writeLine(  FTDI_UARTn, LOW );
}

/*
 *  toggleLED( )
 *
 *   Toggle XF LED to opposite state
 */
static toggleLED(void)
{
    if(CHIP_FGET(ST1_55, XF))
        CHIP_FSET(ST1_55, XF,CHIP_ST1_55_XF_OFF);  // Turn off LED
    else
        CHIP_FSET(ST1_55, XF, CHIP_ST1_55_XF_ON);  // Turn on LED
}

/*
 *  checkTimer( )
 *
 *   See if timer interrupt was triggered. ISR sets timerFlag to 1.
 */
void checkTimer(void)
{
    if(timerFlag == 1)
    {
        timerFlag = 0;    // Set flag back to 0
        toggleLED();      // Toggle XF LED
    }
}

/*
 *  checkSwitch( )
 *
 *   Check if SW1 or SW2 was pressed.
 *     SW1 controls Timer period
 *     SW2 controls Audio Tone
 */
void checkSwitch(void)
{
    /* Check SW1 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW0))) // Is SW1 pressed?
    {
        if(sw1State)          // Was previous state not pressed?
        {
            changeTimer();    // Change timer period
            sw1State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW1 not pressed
        sw1State = 1;         // Set state to 1 to allow timer change
        
    /* Check SW2 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW1))) // Is SW2 pressed?
    {
        if(sw2State)          // Was previous state not pressed?
        {
            changeTimer();    // Change audio tone
            sw2State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW2 not pressed
        sw2State = 1;         // Set state to 1 to allow tone change
}

