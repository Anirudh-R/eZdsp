/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*   noise_gate.c                                                            */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5505 USB Stick.                                                 */
/*   Noise gate with variable attack time and decay time                     */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.01                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision: 1.00                                                          */
/*   18th April 2010. Created by Richard Sikora from TMS320C5510 code.       */
/*                                                                           */
/*   Revision 1.01.                                                          */
/*   8th August 2010. Modified to be compatible with CSL.                    */
/*                                                                           */
/*****************************************************************************/
/*
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#define STATE_IDLE      0
#define STATE_ATTACKING 1
#define STATE_ACTIVE    2
#define STATE_DECAYING  3

/* Scaling factor for sampling rate of 8000 Hz. Declare as long L */
#define SCALING_FACTOR 8L

/* Function prototypes */

static int decay(int input, int decay_time, int decay_time_ms);


/*****************************************************************************/
/* noise_gate()                                                              */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* INPUT 1:  Audio input.                                                    */
/* INPUT 2:  1 = signal. 0 = noise.                                          */
/* INPUT 3:  Attack time in ms                                               */
/* INPUT 4:  Decay time in ms                                                */
/*                                                                           */
/* RETURNS:  Output of noise gate. Noisy signals have zero output.           */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* During the attack phases, the input is divided by 2. Better               */
/* would be for the output to ramp up smoothly.                              */
/*                                                                           */
/*****************************************************************************/

int noise_gate(int input, int signal, int attack_time_ms, int decay_time_ms)
{
 int output;
 static int state = STATE_IDLE;
 static long attack_time;
 static long decay_time;
 
  switch (state)
 {
     case STATE_IDLE:  if ( signal)
                         {
                          attack_time = attack_time_ms * SCALING_FACTOR;
                          state = STATE_ATTACKING;
                         }
                        else
                         {
                           ; /* Do nothing */  
                         }
                      
                        output = 0;  /* No output at all. Silence */  
                        break;
               
     case STATE_ATTACKING:
                        if (0 == attack_time )
                         {
                          state = STATE_ACTIVE; /* attack_time counter has expired */
                         }
                        else 
                          {
                            ; /* Do nothing. attack_time counter still running */  
                          } 
                        attack_time--;     /* Decrement timer */                          
                        output = input/2;  /* Reduce input level */
                        break;          
    
     case STATE_ACTIVE: if ( signal == 0 )
                         {
                          /* Signal no longer present */
                          decay_time = decay_time_ms * SCALING_FACTOR;
                          state = STATE_DECAYING;
                         }
                        else 
                          {
                            ; /* Do nothing. Let signal through */  
                          }                         
                        output = input;
                        break;
                       
     case STATE_DECAYING:
                        if ( signal)
                          {
                           /* A new signal has been detected */
                           attack_time = attack_time_ms * SCALING_FACTOR;
                           state = STATE_ATTACKING;
                          }
                        else if ( 0 == decay_time)
                          {
                           state = STATE_IDLE; 
                          } 
                        else 
                          {
                            ; /* Do nothing */  
                          }
                        decay_time--;  
                        output = decay (input, decay_time, decay_time_ms);
                        break;
                       
  }                                                 
  return (output);            

}

/*****************************************************************************/
/* decay()                                                                   */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* INPUT 1:  Audio input.                                                    */
/* INPUT 2:  Decay counter (counts downwards from decay time in ms to 0).    */
/* INPUT 3:  Total decay time in ms                                          */
/*                                                                           */
/* RETURNS:  Input attenuated by 6 dB, 12 dB, 18 dB or 24 dB.                */
/*                                                                           */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Note: Time limits of 3/4, 1/2 and 1/4 are specified as type long to       */
/* ensuer that the multiplication generates the correct product.             */
/*                                                                           */
/*****************************************************************************/


#define LIMIT1 24575L
#define LIMIT2 16383L
#define LIMIT3 8095L


static int decay (int input, int decay_time, int decay_time_ms)
{
 long product;
 int scaled_time;
 int output;

 product = decay_time_ms * LIMIT1;
 scaled_time = (int) (product >> 15); 

 if ( decay_time > scaled_time)
    {
      output = (input >> 1);
      return (output);       /* Attenuate by 6 dB */
    }

 product = decay_time_ms * LIMIT2;
 scaled_time = (int) (product >> 15); 

 if ( decay_time > scaled_time)
    {
      output = (input >> 2);
      return (output);       /* Attenuate by 12 dB */
    }

 product = decay_time_ms * LIMIT3;
 scaled_time = (int) (product >> 15); 

 if ( decay_time > scaled_time)
    {
      output = (input >> 3);
      return (output);       /* Attenuate by 18 dB */
    }   

 /* Default. Time remaining is less than LIMIT3 */

 return (input >> 4);        /* Attenuate by 24 dB */  


}


/*****************************************************************************/
/* End of noise_gate.c                                                       */
/*****************************************************************************/
