/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*   autocorrelation.c                                                       */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   TMS320C5505 USB Stick. Autocorrelation of data series.                  */
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   4th May 2010. Created by Richard Sikora.                                */
/*                                                                           */
/*****************************************************************************/
/*
 * Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "tms320.h"
#include "dsplib.h"
#include "autocorrelation.h"
#include "Hamming_High_Pass_Filter_150Hz.h"

/* Function prototypes */

static int find_maximum ( DATA * buffer, const int size);
static void normalize( DATA * buffer, const int size, int maximum);
static int number_outside_thresholds (DATA * buffer, const int size, const int threshold_low, const int threshold_high);                 

#define BUFFER_SIZE 128

/* Thresholds determined from statistical 99% confidence limits */
/* -1/N -3/sqrt(N) and -/N + 3/sqrt(N) where N = sample size    */

#define LOW_THRESHOLD_99   -8945
#define HIGH_THRESHOLD_99   8433

#define LOW_THRESHOLD_95   -6048
#define HIGH_THRESHOLD_95   5536

DATA buffer[BUFFER_SIZE+3];            
DATA autocorrelated_data[BUFFER_SIZE];
DATA dbuffer[53];

/*****************************************************************************/
/* signal_or_noise()                                                         */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Determines if the signal in the buffer is signal or noise.                */
/* Technique: Perform autocorrelation then statistical data analysis.        */
/* Note: the processing has been divided into steps for realtime performance.*/
/* PARAMETER 1: Latest audio input sample.                                   */
/* RETURNS:     SIGNAL (1) or NOISE (0)                                      */
/*                                                                           */
/*****************************************************************************/


int signal_or_noise(DATA input)
{
 static unsigned int counter = 0;
 static int maximum = 0; /* Needs to be static to hold values between calls */
 static int result = 0;  /* Must also be static to hold values between calls */
 int number;

 /* Apply high pass filter to remove and 50 Hz or 60 Hz periodic mains noise */
 fir(&input, &Hamming_High_Pass_Filter_150Hz[0], &buffer[counter], &dbuffer[0], 1, 51); /* Store latest input in buffer */
  
 if ( counter < (BUFFER_SIZE-1))
   {
     counter++; /* Point to next buffer location */
   } 
 else if (counter == (BUFFER_SIZE-1))
   {
    /* Receive buffer is now full */
    maximum = find_maximum ( &buffer[0], BUFFER_SIZE);
    counter++; /* Point to next location */          
   }
 else if ( counter == BUFFER_SIZE)
   {
    normalize( &buffer[0], BUFFER_SIZE, maximum);
    counter++;
   }
 else if ( counter == (BUFFER_SIZE+1))
   {
    /* Call autocorrelation algorithm from dsplib       */
    /* Must put "raw", "bias" or "unbias" in lower case */
    /* The values in buffer[] must be between -4096 and +4095, otherwise acorr() overloads */
    
    acorr( &buffer[0], &autocorrelated_data[0], BUFFER_SIZE, 102, raw);
    counter++; 
   }
 else if ( counter == (BUFFER_SIZE+2))
   {
   	/* Ignore the first two values because for random data are high */
    number = number_outside_thresholds (&autocorrelated_data[2], 100, LOW_THRESHOLD_95, HIGH_THRESHOLD_95);  
   
    if ( number > 5)
     {
      /* If noise, would expect 5+ sample outside 95% confidence limits. Must be signal */
      result = SIGNAL;
     }
    else if ( number <= 5)
     {
      /* Only 5 or less samples outside 95% confidence limits. Must be noise or very low signal */
      result = NOISE;  
     }
    else
     {
      ; /* Not possible to tell if signal or noise. Use previous value */ 
     }

    /* Put extra 3 inputs into beginning of buffer for next time through */ 
    buffer[0] = buffer[BUFFER_SIZE];
    buffer[1] = buffer[BUFFER_SIZE+1];
    buffer[2] = buffer[BUFFER_SIZE+2];
    counter= 3; /* We already have next 3 samples. Take in 4th sample next time */
   }
  else
   {
    /* Trap for counter out of range. Default to beginning of buffer */
    counter = 0;   
   }
 
 return(result);
}


/*****************************************************************************/
/* find_maxium()                                                             */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Finds the |maximum| value of a data series.                               */
/* PARAMETER 1: Pointer to array holding data series.                        */
/* PARAMETER 2: Size of data series.                                         */
/* RETURNS:     |Maximum|.                                                   */
/*                                                                           */
/*****************************************************************************/


static int find_maximum ( DATA * buffer, const int size)
{
 int i;
 int maximum = 0;
 int temp;

 for ( i = 0 ; i < size ; i++)
    {
      temp = buffer[i];

      if ( temp < 0)
         {
          temp = - temp; /* Make positive */
         }

      if ( temp > maximum)
         {
           maximum = temp;
         }  
    } 

 return (maximum);
}


/*****************************************************************************/
/* Normalize()                                                               */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Normalizes a data series by multiplying all values by a scaling factor.   */
/* Ranges are in units of -3dB, where -3dB = 0.707 and -6dB = 0.5 etc.       */
/*                                                                           */
/* IMPORTANT: The inputs to the DSPLIB function acorr must be in the range   */
/*            -4096 to +4095, otherwise the function overloads.              */
/*                                                                           */
/* PARAMETER 1: Pointer to array holding data series.                        */
/* PARAMETER 2: Size of data series.                                         */
/* PARAMETER 3: Maximum value in data series.                                */
/* RETURNS:     None.                                                        */
/*                                                                           */
/*****************************************************************************/


static void normalize( DATA * buffer, const int size, int maximum)
{
 int i;
 int scaling_factor = 0; /* Default to zero to indicate not used */
 int shift;
 long result;

 if ( maximum > 23166)
   {
     /* Maximum is in range 23166 to 32767 */
     /* Divide by 8 */
     shift = 3; 
   }
 else if ( maximum > 16383)
   {
     /* Input is in range 16383 to 23166 */
     /* Multiply by 0.707 /4 = 0.175 */ 
      scaling_factor = 23166; /* Multiply by 0.707 */
      shift = 2;              /* Divide by 4 */
   }
 else if ( maximum > 11583) 
   {
      /* Input is in range 11583 to 16383. */
      /* Divide by 4 */ 
      shift = 2;
   }
 else if ( maximum > 8191)
   {
      /* Input is in range 8191 to 11583 */
      /* Multiply by 0.707 / 2 = 0.35 */
      scaling_factor = 23166; /* Multiply by 0.707 */  
      shift = 1;              /* Divide by 2 */     
   } 
 else if ( maximum > 5792)
   {
      /* Input is in range 5792 to 8191. Divide by 2 */
      shift = 1;         
   }
 else if ( maximum > 4095)
   {
      /* Input is in range 4095 to 5792 */
      /* Multiply by 0.707 */
      scaling_factor = 23166; /* Multiply by 0.707 */  
      shift = 0; /* Divide by 1 */     
   }
 else if ( maximum > 2896)
   {
      /* Input is in range 2896 to 4095. No scaling required*/ 
      shift = 0;         
   }
 else if ( maximum > 2047)
   {
      /* Input is in range 2047 to 2896 */
      /* Multiply by 0.707 */
      scaling_factor = 23166; /* Multiply by 0.707 */  
      shift = -1 ;            /* Multiply by 2 */     
   }
 else if ( maximum > 1448)
   {
      /* Input is in range 1448 to 2047. Multiply by 2 */
      shift = -1;         
   }
  else if ( maximum > 1023)
   {
      /* Input is in range 1023 to 1448 */
      /* Multiply by 0.707 */
      scaling_factor = 23166; /* Multiply by 0.707 */  
      shift = -2 ;            /* Multiply by 2 */     
   }
 else if ( maximum > 724)
   {
      /* Input is in range 724 to 1023. Multiply by 2 */
      shift = -2;         
   }  
 else
   {
     /* Very low signal. No point in normalizing */
     return; 
   } 

 for ( i = 0 ; i < size ; i++)
  {
     if ( scaling_factor != 0)
       {
         result = (long) buffer[i] * scaling_factor;
         buffer[i] = (int)(result >> ( 15 + shift));   
       }
     else
       {
         /* Scaling factor not required. */
         
         if ( shift < 0)
           {
            buffer[i] <<= -shift; /* Negative shift. Multiply */
           }
         else
           {  
            buffer[i] >>= shift; /* Simple divide by 2, 4, 8 */
           }  
       }   

  }

}


/*****************************************************************************/
/* number_outside_thresholds()                                               */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* Sums the number of values in the data series outside the thresholds.      */
/* PARAMETER 1: Pointer to array holding data series.                        */
/* PARAMETER 2: Size of data series.                                         */
/* PARAMETER 3: Low threshold (lower statistical confidence limit).          */
/* PARAMETER 4: High threshold (upper statistical confidence limit).         */
/* RETURNS: Number of values outsides the thresholds.                        */
/*                                                                           */
/*****************************************************************************/


static int number_outside_thresholds (DATA * buffer, const int size, const int threshold_low, const int threshold_high)  
{
 int i;
 int number = 0;
 int temp; 

 for ( i = 0 ; i < size ; i++ )
 {
   temp = buffer[i];

   if ( temp > threshold_high)
     {
      number++;
     }
   else if ( temp < threshold_low)
     {
      number++;
     }
   else
     {
      ; /* Value is inside limits. */
     } 
 }

 return (number);

}

/*****************************************************************************/
/* End of signal_or_noise.c                                                  */
/*****************************************************************************/
