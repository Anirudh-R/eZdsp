//////////////////////////////////////////////////////////////////////////////
// * File name: dma.c
// *                                                                          
// * Description:  DMA functions.
// *                                                                          
// * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/ 
// * Copyright (C) 2011 Spectrum Digital, Incorporated
// *                                                                          
// *                                                                          
// *  Redistribution and use in source and binary forms, with or without      
// *  modification, are permitted provided that the following conditions      
// *  are met:                                                                
// *                                                                          
// *    Redistributions of source code must retain the above copyright        
// *    notice, this list of conditions and the following disclaimer.         
// *                                                                          
// *    Redistributions in binary form must reproduce the above copyright     
// *    notice, this list of conditions and the following disclaimer in the   
// *    documentation and/or other materials provided with the                
// *    distribution.                                                         
// *                                                                          
// *    Neither the name of Texas Instruments Incorporated nor the names of   
// *    its contributors may be used to endorse or promote products derived   
// *    from this software without specific prior written permission.         
// *                                                                          
// *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
// *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
// *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
// *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
// *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
// *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
// *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
// *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
// *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
// *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
// *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
#include"ezdsp5502.h"
#include"ezdsp5502_mcbsp.h"
#include "csl_dma.h"

DMA_Handle hDmaRcv;
DMA_Handle hDmaTxm;

Int16 mcbsp_datain[2];

/* DMA transmit configuration structure */
DMA_Config myconfigTxm = { 
    DMA_DMACSDP_RMK(
        DMA_DMACSDP_DSTBEN_NOBURST , // Destination burst
        DMA_DMACSDP_DSTPACK_OFF,     // Destination packing
        DMA_DMACSDP_DST_PERIPH ,     // Source selection
        DMA_DMACSDP_SRCBEN_NOBURST , // Source burst
        DMA_DMACSDP_SRCPACK_OFF,     // Source packing
        DMA_DMACSDP_SRC_DARAMPORT1 , // Source selection
        DMA_DMACSDP_DATATYPE_16BIT   // Data type
    ), /* DMACSDP */
   
    DMA_DMACCR_RMK(
        DMA_DMACCR_DSTAMODE_CONST,   // Destination address mode
        DMA_DMACCR_SRCAMODE_POSTINC,   // Source address mode
        DMA_DMACCR_ENDPROG_OFF,      // End of programmation bit
        DMA_DMACCR_WP_DEFAULT,
        DMA_DMACCR_REPEAT_ALWAYS,    // Repeat condition
        DMA_DMACCR_AUTOINIT_ON,      // Auto initialization bit
        DMA_DMACCR_EN_STOP,          // Channel enable
        DMA_DMACCR_PRIO_LOW,         // Channel priority
        DMA_DMACCR_FS_ELEMENT,       // Frame\Element Sync
        DMA_DMACCR_SYNC_XEVT1        // Synchronization control
    ), /* DMACCR */
    
    DMA_DMACICR_RMK(
        DMA_DMACICR_AERRIE_OFF,
        DMA_DMACICR_BLOCKIE_OFF ,    // Whole block interrupt enable
        DMA_DMACICR_LASTIE_OFF,      // Last frame Interrupt enable
        DMA_DMACICR_FRAMEIE_OFF,     // Whole frame interrupt enable
        DMA_DMACICR_FIRSTHALFIE_OFF, // HAlf frame interrupt enable
        DMA_DMACICR_DROPIE_OFF,      // Sync event drop interrupt enable
        DMA_DMACICR_TIMEOUTIE_OFF    // Time out inetrrupt enable
    ), /* DMACICR */
    
    (DMA_AdrPtr)0x5000, // DMACSSAL - DMA source set to random location (Set to sine array later)
    0,                  // DMACSSAU
    (DMA_AdrPtr)0x5804, // DMACDSAL - DMA destination is DXR1
    0,                  // DMACDSAU 
    2,                  // DMACEN  - 96 elements (48 for each channel)
    1,                  // DMACFN  - Single frame
    0,                  // DMACSFI - Source frame index
    0,                  // DMACSEI - Source element index
    0,                  // DMACDFI - Destination frame index
    0                   // DMACDEI - Destination element index
};

/* DMA receive configuration structure */
DMA_Config myconfigRcv = { 
    DMA_DMACSDP_RMK(
        DMA_DMACSDP_DSTBEN_NOBURST , // Destination burst
        DMA_DMACSDP_DSTPACK_OFF,     // Destination packing
        DMA_DMACSDP_DST_DARAMPORT1 , // Source selection
        DMA_DMACSDP_SRCBEN_NOBURST , // Source burst
        DMA_DMACSDP_SRCPACK_OFF,     // Source packing
        DMA_DMACSDP_SRC_PERIPH ,     // Source selection
        DMA_DMACSDP_DATATYPE_16BIT   // Data type
    ), /* DMACSDP */
   
    DMA_DMACCR_RMK(
        DMA_DMACCR_DSTAMODE_POSTINC,   // Destination address mode
        DMA_DMACCR_SRCAMODE_CONST,   // Source address mode
        DMA_DMACCR_ENDPROG_OFF,      // End of programmation bit
        DMA_DMACCR_WP_DEFAULT,
        DMA_DMACCR_REPEAT_ALWAYS,    // Repeat condition
        DMA_DMACCR_AUTOINIT_ON,      // Auto initialization bit
        DMA_DMACCR_EN_STOP,          // Channel enable
        DMA_DMACCR_PRIO_HI,         // Channel priority
        DMA_DMACCR_FS_ELEMENT,       // Frame\Element Sync
        DMA_DMACCR_SYNC_REVT1        // Synchronization control
    ), /* DMACCR */
    
    DMA_DMACICR_RMK(
        DMA_DMACICR_AERRIE_OFF,
        DMA_DMACICR_BLOCKIE_OFF ,    // Whole block interrupt enable
        DMA_DMACICR_LASTIE_OFF,      // Last frame Interrupt enable
        DMA_DMACICR_FRAMEIE_OFF,     // Whole frame interrupt enable
        DMA_DMACICR_FIRSTHALFIE_OFF, // HAlf frame interrupt enable
        DMA_DMACICR_DROPIE_OFF,      // Sync event drop interrupt enable
        DMA_DMACICR_TIMEOUTIE_OFF    // Time out inetrrupt enable
    ), /* DMACICR */
    
    (DMA_AdrPtr)0x5800, // DMACSSAL - DMA source is DRR1
    0,                  // DMACSSAU
    (DMA_AdrPtr)0x5000, // DMACDSAL - DMA destination set to random location (Set to sine array later)
    0,                  // DMACDSAU 
    2,                  // DMACEN  - 96 elements (48 for each channel)
    1,                  // DMACFN  - Single frame
    0,                  // DMACSFI - Source frame index
    0,                  // DMACSEI - Source element index
    0,                  // DMACDFI - Destination frame index
    0                   // DMACDEI - Destination element index
};


/*
 *  configAudioDma( )
 *
 *    Configure DMA for Audio
 */
void configAudioDma (void)
{
    /* Set source address to Sine_1K */
    myconfigTxm.dmacssal = (DMA_AdrPtr)(((Uint32)&mcbsp_datain[0]) << 1);
    hDmaTxm = DMA_open(DMA_CHA0, DMA_OPEN_RESET);  // Open DMA Channel 0
    DMA_config(hDmaTxm, &myconfigTxm);   // Configure Channel
    
    myconfigRcv.dmacdsal = (DMA_AdrPtr)(((Uint32)&mcbsp_datain[0]) << 1);
    hDmaRcv = DMA_open(DMA_CHA1, DMA_OPEN_RESET);  // Open DMA Channel 0
    DMA_config(hDmaRcv, &myconfigRcv);   // Configure Channel
    
}

/*
 *  startAudioDma( )
 *
 *    Start DMA transfer for Audio
 */
void startAudioDma (void)
{   
	mcbsp_datain[0]=0;
	mcbsp_datain[1]=0;
    DMA_start(hDmaRcv); // Begin Transfer
    DMA_start(hDmaTxm); // Begin Transfer
}

/*
 *  stopAudioDma( )
 *
 *    Stop DMA transfer for Audio
 */
void stopAudioDma (void)
{
    DMA_stop(hDmaTxm);  // Stop Transfer
    DMA_stop(hDmaRcv);  // Stop Transfer
}

/*
 *  changeTone( )
 *
 *    Swap between 1KHz and 2KHz audio tones
 */
