//////////////////////////////////////////////////////////////////////////////
// * File name: main.c
// *                                                                          
// * Description:  Main function.
// *                                                                          
// * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/ 
// * Copyright (C) 2011 Spectrum Digital, Incorporated
// *                                                                          
// *                                                                          
// *  Redistribution and use in source and binary forms, with or without      
// *  modification, are permitted provided that the following conditions      
// *  are met:                                                                
// *                                                                          
// *    Redistributions of source code must retain the above copyright        
// *    notice, this list of conditions and the following disclaimer.         
// *                                                                          
// *    Redistributions in binary form must reproduce the above copyright     
// *    notice, this list of conditions and the following disclaimer in the   
// *    documentation and/or other materials provided with the                
// *    distribution.                                                         
// *                                                                          
// *    Neither the name of Texas Instruments Incorporated nor the names of   
// *    its contributors may be used to endorse or promote products derived   
// *    from this software without specific prior written permission.         
// *                                                                          
// *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
// *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
// *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
// *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
// *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
// *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
// *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
// *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
// *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
// *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
// *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
#include "ezdsp5502.h"
#include "ezdsp5502_mcbsp.h"
#include "ezdsp5502_i2cgpio.h"
#include "dma.h"
#include "timer.h"
#include "lcd.h"
#include "i2cgpio.h"
#include "csl_chip.h"
#include "csl_mcbsp.h"
#include "stdio.h"

void configPort(void);
void checkTimer(void);
void checkSwitch(void);

extern void initPLL(void);
extern void initAIC3204( );
extern Int16 oled_start( );

extern Uint16 timerFlag;  // Timer interrupt flag
//extern Int16 mcbsp_datain[2];
//extern void* aicMcbsp;

Uint8 ledNum = 3;         // I2C GPIO LED number
Uint8 sw1State = 0;       // SW1 state
Uint8 sw2State = 0;       // SW2 state
Int16 data_in_L=0;
Int16 data_in_R=0;
Int16 data_out_L=0;
Int16 data_out_R=0;
long temp=0;
long temp1=0;
long sine_val=0;

/*Uint16 Sine_1K[96] = {
0x0000,0x0000,0x0B6C,0x0B6C,0x16A6,0x16A6,0x217C,0x217C,0x2BC0,0x2BC0,0x3544,0x3544,0x3DDF,0x3DDF,0x456B,0x456B, 
0x4BC7,0x4BC7,0x50D7,0x50D7,0x5485,0x5485,0x56C0,0x56C0,0x5780,0x5780,0x56C0,0x56C0,0x5485,0x5485,0x50D7,0x50D7, 
0x4BC7,0x4BC7,0x456B,0x456B,0x3DDF,0x3DDF,0x3544,0x3544,0x2BC0,0x2BC0,0x217C,0x217C,0x16A6,0x16A6,0x0B6C,0x0B6C, 
0x0000,0x0000,0xF494,0xF494,0xE95A,0xE95A,0xDE84,0xDE84,0xD440,0xD440,0xCABC,0xCABC,0xC221,0xC221,0xBA95,0xBA95, 
0xB439,0xB439,0xAF29,0xAF29,0xAB7B,0xAB7B,0xA940,0xA940,0xA880,0xA880,0xA940,0xA940,0xAB7B,0xAB7B,0xAF29,0xAF29, 
0xB439,0xB439,0xBA95,0xBA95,0xC221,0xC221,0xCABC,0xCABC,0xD440,0xD440,0xDE84,0xDE84,0xE95A,0xE95A,0xF494,0xF494
};*/

Int16 Sine_500[96] = {0,196,392,585,776,964,1148,1327,1500,1667,1826,1978,2121,2256,2380,2494,2598,2691,
2772,2841,2898,2942,2974,2994,3000,2994,2974,2942,2898,2841,2772,2691,2598,2494,2380,2256,2121,1978,1826,
1667,1500,1327,1148,964,776,585,392,196,0,-196,-392,-585,-776,-964,-1148,-1327,-1500,-1667,-1826,-1978,
-2121,-2256,-2380,-2494,-2598,-2691,-2772,-2841,-2898,-2942,-2974,-2994,-3000,-2994,-2974,-2942,-2898,
-2841,-2772,-2691,-2598,-2494,-2380,-2256,-2121,-1978,-1826,-1667,-1500,-1327,-1148,-964,-776,-585,-392,
-196};
void main(void)
{   
	Uint16 index=0;
	
    /* Demo Initialization */
    initPLL( );         // Initialize PLL
    EZDSP5502_init( );  // Board Initialization
    initLed( );         // Init I2C GPIO for LEDs
    configPort( );      // Configure MUXs
    initTimer0( );      // Initialize timer
    initAIC3204( );     // Initialize AIC3204
    configAudioDma( );  // Configure DMA for Audio tone
    
    /* Start Demo */
    oled_start( );            // Configure and start output on display
    startTimer0( );           // Start timer
    //startAudioDma ( );      // Start DMA to service McBSP
    EZDSP5502_MCBSP_init( );  // Configure and start McBSP
    
    while(1)
    {
    	EZDSP5502_MCBSP_read(&data_in_L);
    	EZDSP5502_MCBSP_read(&data_in_R);
    	
    	temp = ((long)data_in_L+(long)data_in_R);
    	temp = temp>>1;
    	temp=temp+115;
    	if(temp>-25 && temp<25) 
    	temp=0; 
    	
    	temp1=temp;
    	
    	sine_val = ((long)Sine_500[index])>>6;
    	temp = temp*sine_val;
    	temp = temp>>5;
    	data_out_L = (Int16)(temp + temp1/16);
    	data_out_R = (Int16)(temp + temp1/16);
    	
    	EZDSP5502_MCBSP_write(data_out_L);
    	EZDSP5502_MCBSP_write(data_out_R);
    	
    	if(index==95)
    	index=0;
    	else
    	index=index+1;
    }

}



/*
 *  configPort( )
 *
 *   Configure MUXs for AIC3204
 */
void configPort(void)
{
    /* Set to McBSP1 mode */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1, LOW );
    
    /* Enable McBSP1 */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1_ENn, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1_ENn, LOW );
}

/*
 *  toggleLED( )
 *
 *   Toggle XF LED to opposite state
 */
//static toggleLED(void)
//{
//    if(CHIP_FGET(ST1_55, XF))
//        CHIP_FSET(ST1_55, XF,CHIP_ST1_55_XF_OFF);  // Turn off LED
//    else
//        CHIP_FSET(ST1_55, XF, CHIP_ST1_55_XF_ON);  // Turn on LED
//}

/*
 *  checkTimer( )
 *
 *   See if timer interrupt was triggered. ISR sets timerFlag to 1.
 */
//void checkTimer(void)
//{
//    if(timerFlag ==1)
//    {
//        timerFlag =0;    // Set flag back to 0
//        toggleLED();     // Toggle XF LED
//        EZDSP5502_I2CGPIO_writeLine( ledNum,   // Toggle User LED ledNum
//                 (~EZDSP5502_I2CGPIO_readLine(ledNum) & 0x01) );
//        if( ledNum > 6)  // I2C GPIOs 3 to 6 control LEDs
//            ledNum = 3;  // Go back to first LED
//        ledNum++;        // Go to next LED
//    }
//}

/*
 *  checkSwitch( )
 *
 *   Check if SW1 or SW2 was pressed.
 *     SW1 controls Timer period
 *     SW2 controls Audio Tone
 */
void checkSwitch(void)
{
    /* Check SW1 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW0))) // Is SW1 pressed?
    {
        if(sw1State)          // Was previous state not pressed?
        {
            changeTimer();    // Change timer period
            sw1State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW1 not pressed
        sw1State = 1;         // Set state to 1 to allow timer change
        
    /* Check SW2 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW1))) // Is SW2 pressed?
    {
        if(sw2State)          // Was previous state not pressed?
        {
            changeTimer();    // Change audio tone
            sw2State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW2 not pressed
        sw2State = 1;         // Set state to 1 to allow tone change
}

