/*****************************************************************************/
/*                                                                           */
/* FILENAME                                                                  */
/*  echo.h                                                                   */
/*                                                                           */
/* DESCRIPTION                                                               */
/*   Header file to generate echo effect using an finite impulse             */
/*   response (FIR) filter configuration.                                    */                                               
/*                                                                           */
/* REVISION                                                                  */
/*   Revision: 1.00                                                          */
/*   Author  : Richard Sikora                                                */
/*---------------------------------------------------------------------------*/
/*                                                                           */
/* HISTORY                                                                   */
/*   Revision 1.00                                                           */
/*   27th January 2010. Created by Richard Sikora from reverberation.h       */
/*                                                                           */
/*****************************************************************************/

#ifndef echo_H
#define echo_H
 
 void echo_array_clear(void);              
 
 Int16 echo( Int16 latest_input);
 
 Int16 variable_echo(Int16 latest_input, Uint16 length, Uint16 depth);
 
#endif

/*****************************************************************************/
/* End of echo.c                                                    */
/*****************************************************************************/



  
