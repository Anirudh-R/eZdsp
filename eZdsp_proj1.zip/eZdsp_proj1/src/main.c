//////////////////////////////////////////////////////////////////////////////
// * File name: main.c
// *                                                                          
// * Description:  Main function.
// *                                                                          
// * Copyright (C) 2011 Texas Instruments Incorporated - http://www.ti.com/ 
// * Copyright (C) 2011 Spectrum Digital, Incorporated
// *                                                                          
// *                                                                          
// *  Redistribution and use in source and binary forms, with or without      
// *  modification, are permitted provided that the following conditions      
// *  are met:                                                                
// *                                                                          
// *    Redistributions of source code must retain the above copyright        
// *    notice, this list of conditions and the following disclaimer.         
// *                                                                          
// *    Redistributions in binary form must reproduce the above copyright     
// *    notice, this list of conditions and the following disclaimer in the   
// *    documentation and/or other materials provided with the                
// *    distribution.                                                         
// *                                                                          
// *    Neither the name of Texas Instruments Incorporated nor the names of   
// *    its contributors may be used to endorse or promote products derived   
// *    from this software without specific prior written permission.         
// *                                                                          
// *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     
// *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       
// *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   
// *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT    
// *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   
// *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT        
// *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   
// *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   
// *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT     
// *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   
// *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
// *                                                                          
//////////////////////////////////////////////////////////////////////////////
#include "ezdsp5502.h"
#include "ezdsp5502_i2cgpio.h"
#include "timer.h"
#include "lcd.h"
#include "i2cgpio.h"
#include "csl_chip.h"
#include "stdio.h"

void configPort(void);
void checkTimer(void);
void checkSwitch(void);
void toggleXF(void);
void Board_init(void);

extern void initPLL(void);
extern Int16 oled_start( );

extern Uint16 timerFlag;  // Timer interrupt flag

Uint16 ledNum = 4;         // I2C GPIO LED number
Uint8 sw1State = 1;       // SW1 state
Uint8 sw2State = 1;       // SW2 state

void main(void)
{
	Board_init();       //Initialize board
	
	EZDSP5502_I2CGPIO_writeLine(ledNum, LOW );
    initTimer0( );      // Initialize timer
    startTimer0( );     // Start timer
    oled_start( );      // Configure and start output on display
    
    printf( "\nInit done.\n");
    
    while(1)
    {
        checkTimer( );  // Check if timer interrupt was triggered
        checkSwitch( ); // Check if a switch was pressed
    }
}


void toggleXF(void)
{
    if(CHIP_FGET(ST1_55, XF))
        CHIP_FSET(ST1_55, XF,CHIP_ST1_55_XF_OFF);  // Turn off LED
    else
        CHIP_FSET(ST1_55, XF, CHIP_ST1_55_XF_ON);  // Turn on LED
}

void checkTimer(void)
{
    if(timerFlag ==1)
    {
        timerFlag =0;    // Set flag back to 0
        toggleXF();     // Toggle XF LED
    }
}

void checkSwitch(void)
{
    /* Check SW1 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW0))) // Is SW1 pressed?
    {
        if(sw1State)          // Was previous state not pressed?
        {
        	EZDSP5502_I2CGPIO_write( 0x02, 0xFF );
            ledNum--; if(ledNum<4) ledNum=7;
            EZDSP5502_I2CGPIO_writeLine(ledNum, LOW );
            printf( "LED: "); printf("%u\n",ledNum);
            sw1State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW1 not pressed
        sw1State = 1;         // Set state to 1 to allow timer change
        
    /* Check SW2 */
    if(!(EZDSP5502_I2CGPIO_readLine(SW1))) // Is SW2 pressed?
    {
        if(sw2State)          // Was previous state not pressed?
        {
        	EZDSP5502_I2CGPIO_write( 0x02, 0xFF );
            ledNum++; if(ledNum>7) ledNum=4;
            EZDSP5502_I2CGPIO_writeLine(ledNum, LOW );
            printf( "LED: "); printf( "%u\n",ledNum);
            sw2State = 0;     // Set state to 0 to allow only single press
        }
    }
    else                      // SW2 not pressed
        sw2State = 1;         // Set state to 1 to allow tone change
}

void Board_init(void)
{
    initPLL( );         // Initialize PLL
    EZDSP5502_init( );  // Board Initialization
    initLed( );         // Init I2C GPIO for LEDs
    configPort( );      // Configure MUXs	
}

void configPort(void)
{
    /* Set to McBSP1 mode */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1, LOW );
    
    /* Enable McBSP1 */
    EZDSP5502_I2CGPIO_configLine( BSP_SEL1_ENn, OUT );
    EZDSP5502_I2CGPIO_writeLine(  BSP_SEL1_ENn, LOW );
}
